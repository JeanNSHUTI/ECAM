<html>
	<head>

	<h1>DETAIL DES RESERVATIONS</h1>

	</head>

	<body>

<?php
	$age = $_POST["age"] . "";
	$name = $_POST["name"] . "";
	if(isset($_POST['change_page']) AND ($_POST['change_page'] == 'Retour à la page précédente')) { header("Location:reservation.html"); } 
	
		 echo '<input type="submit" value="Etape suivante">';
		 echo '<input type="submit" name="change_page" value="Retour à la page précédente">';
		 echo '<input type="submit" value="Annuler la réserevation">';
		 //echo $age;
		 //echo $name;
?>
	
	</body>
	</html>