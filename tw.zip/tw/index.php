 <?php

	echo "Hello " 
?>
<html>

<head>

<h1>RESERVATION</h1>

</head>

<body>

<p>Le prix de la place est de 10 euros jusqu'à 12 ans, et ensuite de 15 euros.</p>

<p>Le prix de l'assurance est de 20 euros quel que soit le nombre des voyageurs.</p>
<form method="post" action="handler.php"> 
  Destination:<br>
  <input type="text" name="destination">
  <br>
  Nombre de personnes:<br>
  <input type="text" name="nbperson">
  <br>
  Assurance annulation: <br>
  <input type="checkbox" name="insurance" value="Insurance" checked>
  <br>
  <input type="submit" value="Etape suivante">
  <input type="submit" value="Annuler la réserevation">

</form>

</body>
</html>
