 <html>
	<head>
    <link rel="stylesheet" type="text/css" href="mystyle.css" media="screen" />
	<h1>DETAIL DES RESERVATIONS</h1>

	</head>

	<body>

<?php
	if(isset($_POST['destination'])) 
	{
		$destination = $_POST["destination"];
	}
	
		if(isset($_POST['nbperson'])) 
	{
		$nbperson = $_POST["nbperson"];
	}
	echo '<fieldset>';
	for ($count = 0; $count < $nbperson; $count++) 
	{
		echo '<form method= "post" action = "handler1.php">';
			 
				 echo 'Nom:';
				 echo '<input type="text" name="name">';
				 echo '<br>';
				 echo 'Age:';
				 echo '<input type="text" name="age">';
				 echo '<br>';
				 echo '<br>';
		
	echo '</form>';
		 
	}
	echo '</fieldset>';
	echo '<br>';
	
		 echo '<input type="submit" value="Etape suivante">';
		 echo '<input type="submit" name="change_page" value="Retour à la page précédente">';
		 echo '<input type="submit" value="Annuler la réserevation">';
?>
	
	</body>
	</html>